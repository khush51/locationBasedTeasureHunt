package com.example.treasurehunt;

public class GameDetails {

    long score;
    Double longitude;
    Double latitude;
    String locality;
    String username;
    int cur_clue;
    int no_of_location;

}
