package com.example.treasurehunt;

public class Scores {

    String username;
    String level;
    String score;

}
