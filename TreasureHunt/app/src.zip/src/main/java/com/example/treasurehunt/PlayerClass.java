package com.example.treasurehunt;

public class PlayerClass {

    String name;
    String username;
    String points;
    String no_complete_sets;

}
