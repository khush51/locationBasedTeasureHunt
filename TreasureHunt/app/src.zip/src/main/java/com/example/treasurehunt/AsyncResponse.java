package com.example.treasurehunt;

public interface AsyncResponse {
    void processFinish(String output);
}
