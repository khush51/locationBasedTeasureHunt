package com.example.treasurehunt;

import java.util.ArrayList;

public class DemoData {

//    static ArrayList<PlayerClass> players = new ArrayList<>();
    static ArrayList<LocationClass> locations = new ArrayList<>();
//    static ArrayList<GameDetails> gameDetails = new ArrayList<>();

    static PlayerClass loggedInPlayer = new PlayerClass();
    static GameDetails gameDetails = new GameDetails();

//    static String selectedLocality;

//    static Boolean flag;

}
